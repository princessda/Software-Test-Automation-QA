import java.time.LocalDate;
import java.time.LocalDateTime;

public class Appointment {
    private final String appointmentId;
    private final LocalDateTime appointmentDate; // Using LocalDateTime for better time handling
    private final String description;

    // Constructor with validation
    public Appointment(String appointmentId, LocalDateTime appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID cannot be null or longer than 10 characters.");
        }
        if (appointmentDate == null || appointmentDate.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null or longer than 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getter methods
    public String getAppointmentId() {
        return appointmentId;
    }

    public LocalDateTime getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
