import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("123", new Date(System.currentTimeMillis() + 100000), "Test Appointment");
        
        // Adding appointment to the service
        service.addAppointment(appointment);
        // Verify the appointment is added correctly
        assertEquals(appointment, service.getAppointment("123"));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("123", new Date(System.currentTimeMillis() + 100000), "Test Appointment");
        
        // Adding and then deleting the appointment
        service.addAppointment(appointment);
        service.deleteAppointment("123");
        
        // Verify the appointment was deleted correctly
        assertNull(service.getAppointment("123"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("123", new Date(System.currentTimeMillis() + 100000), "Test Appointment");
        
        // Adding the first appointment
        service.addAppointment(appointment);
        
        // Trying to add the same appointment again (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);  // Should throw exception for duplicate ID
        });
    }

    @Test
    public void testAddAppointmentWithInvalidDate() {
        AppointmentService service = new AppointmentService();
        
        // Creating an invalid appointment with a past date
        Appointment invalidAppointment = new Appointment("123", new Date(System.currentTimeMillis() - 100000), "Test Appointment");
        
        // This should throw an IllegalArgumentException because the date is in the past
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(invalidAppointment);  // Should throw exception for past date
        });
    }
}