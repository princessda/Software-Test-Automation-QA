import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        // Testing a valid appointment with a future date
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 100000), "Doctor Appointment");
        assertNotNull(appointment);
        assertEquals("12345", appointment.getAppointmentId());
        assertNotNull(appointment.getAppointmentDate());
        assertEquals("Doctor Appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentIdTooLong() {
        // Testing invalid Appointment ID (too long)
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(System.currentTimeMillis() + 100000), "Doctor Appointment");
        });
    }

    @Test
    public void testInvalidAppointmentDateInPast() {
        // Testing invalid Appointment Date (in the past)
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() - 100000), "Doctor Appointment");
        });
    }

    @Test
    public void testInvalidDescriptionTooLong() {
        // Testing invalid Description (too long)
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() + 100000), "This description is way too long and exceeds the allowed limit of fifty characters.");
        });
    }
}