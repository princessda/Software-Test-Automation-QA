import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTask() {
        Task task = new Task("1", "Test Task", "This is a test description.");
        assertNotNull(task);
        assertEquals("1", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Test", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Test", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("", "Test", "Description")); // empty taskId
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "This name is too long", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "", "Description")); // empty name
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Test", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Test", "This description is way too long for the allowed limit of fifty characters."));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Test", "")); // empty description
    }

    @Test
    public void testValidTaskIdLength() {
        // Testing the exact boundary of the valid task ID length (10 characters)
        Task task = new Task("1234567890", "Valid Task", "Description");
        assertNotNull(task);
        assertEquals("1234567890", task.getTaskId());
    }
}
