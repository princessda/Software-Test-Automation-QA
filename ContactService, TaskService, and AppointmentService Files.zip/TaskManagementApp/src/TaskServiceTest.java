import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Test Task", "Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Test Task", "Description");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("1", "Test Task", "Description");
        taskService.addTask(task);
        taskService.updateTask("1", "Updated Task", "Updated Description");
        Task updatedTask = taskService.getTask("1");
        assertEquals("Updated Task", updatedTask.getName());
        assertEquals("Updated Description", updatedTask.getDescription());
    }

    @Test
    public void testTaskNotFoundForUpdate() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("nonexistent", "New Name", "New Description"));
    }

    @Test
    public void testDeleteTaskNotFound() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("nonexistent"));
    }
}
