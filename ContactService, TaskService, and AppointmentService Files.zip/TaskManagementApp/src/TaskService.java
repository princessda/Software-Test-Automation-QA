import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    // Constructor to initialize the tasks map
    public TaskService() {
        tasks = new HashMap<>();
    }

    // Add a task
    public void addTask(Task task) {
        if (task == null || task.getTaskId() == null) {
            throw new IllegalArgumentException("Task or Task ID cannot be null.");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task with this ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Get a task by its ID
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // Delete a task by its ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found.");
        }
        tasks.remove(taskId);
    }

    // Update a task's name and description using setters from Task class
    public void updateTask(String taskId, String newName, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }

        // Use the setters to update the task's name and description
        task.setName(newName); // Assuming you've implemented the setter in Task class
        task.setDescription(newDescription); // Assuming you've implemented the setter in Task class
    }
}
