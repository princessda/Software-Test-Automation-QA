package ContactService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        // Initialize the service and a sample contact before each test
        contactService = new ContactService();
        contact = new Contact("C001", "John", "Doe", "1234567890", "123 Elm St");
    }

    @Test
    public void testAddContact() {
        // Add the contact
        contactService.addContact(contact);

        // Verify that the contact was added correctly
        assertNotNull(contactService.getContactById("C001"), "Contact should not be null after adding.");
    }

    @Test
    public void testAddDuplicateContact() {
        // Add the contact
        contactService.addContact(contact);

        // Try adding the same contact again (should throw an exception)
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact);
        });

        // Verify the exception message
        assertEquals("Contact with this ID already exists.", thrown.getMessage());
    }

    @Test
    public void testDeleteContact() {
        // Add the contact
        contactService.addContact(contact);

        // Now delete the contact
        contactService.deleteContact("C001");

        // Verify that the contact has been deleted
        assertNull(contactService.getContactById("C001"), "Contact should be null after deletion.");
    }

    @Test
    public void testDeleteNonExistentContact() {
        // Trying to delete a non-existent contact should throw an exception
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("C999");
        });

        // Verify the exception message
        assertEquals("Contact not found.", thrown.getMessage());
    }

    @Test
    public void testUpdateContact() {
        // Add the contact
        contactService.addContact(contact);

        // Update the first name
        contactService.updateContact("C001", "firstName", "Jane");

        // Verify that the first name was updated
        assertEquals("Jane", contactService.getContactById("C001").getFirstName(), "First name should be updated.");
    }

    @Test
    public void testUpdateContactWithInvalidId() {
        // Trying to update a non-existing contact should throw an exception
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("C999", "firstName", "Invalid");
        });

        // Verify the exception message
        assertEquals("Contact not found.", thrown.getMessage());
    }

    @Test
    public void testUpdateContactWithInvalidField() {
        // Add the contact
        contactService.addContact(contact);

        // Trying to update a non-existent field should throw an exception
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("C001", "invalidField", "Invalid");
        });

        // Verify the exception message
        assertEquals("Invalid field name: invalidField", thrown.getMessage());
    }
}



