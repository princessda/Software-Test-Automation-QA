package ContactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // Store contacts by their unique contact ID
    private Map<String, Contact> contacts = new HashMap<>();

    // Add a new contact to the service
    public void addContact(Contact contact) {
        if (contact == null || contact.getContactId() == null) {
            throw new IllegalArgumentException("Contact or ID cannot be null.");
        }
        // Check if the contact with this ID already exists
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact with this ID already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete a contact by its unique ID
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contacts.remove(contactId);
    }

    // Update the fields of an existing contact
    public void updateContact(String contactId, String fieldName, String newValue) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }

        switch (fieldName.toLowerCase()) {
            case "firstname":
                contact.setFirstName(newValue);
                break;
            case "lastname":
                contact.setLastName(newValue);
                break;
            case "phonenumber":
                contact.setPhone(newValue);
                break;
            case "address":
                contact.setAddress(newValue);
                break;
            default:
                throw new IllegalArgumentException("Invalid field name: " + fieldName);
        }
    }

    // Retrieve a contact by its unique ID
    public Contact getContactById(String contactId) {
        return contacts.get(contactId);
    }

    // Optional: Retrieve all contacts for testing purposes
    public Map<String, Contact> getAllContacts() {
        return contacts;
    }
}
